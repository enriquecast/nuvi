
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipoproblematicas`
--

DROP TABLE IF EXISTS `tipoproblematicas`;
CREATE TABLE `tipoproblematicas` (
  `idTipoProblematica` int(11) NOT NULL,
  `tipoProblematica` varchar(45) DEFAULT NULL,
  `detalleProblematica` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
