
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos`
--

DROP TABLE IF EXISTS `proyectos`;
CREATE TABLE `proyectos` (
  `idProyecto` int(11) NOT NULL,
  `nombreProyecto` varchar(45) DEFAULT NULL,
  `fechaInicioProyecto` date DEFAULT NULL,
  `fechaFinProyecto` date DEFAULT NULL,
  `costoMaterial` float DEFAULT NULL,
  `costoPersonal` float DEFAULT NULL,
  `costoProyecto` float DEFAULT NULL,
  `dineroRecaudado` float DEFAULT NULL,
  `dineroFaltante` float DEFAULT NULL,
  `solucionProyecto` varchar(1000) DEFAULT NULL,
  `fkFamilia` int(11) DEFAULT NULL,
  `estado` enum('Abierto','En asignación','En proceso','cerrado') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
