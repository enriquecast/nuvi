
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `tipodocumentos`
--

DROP TABLE IF EXISTS `tipodocumentos`;
CREATE TABLE `tipodocumentos` (
  `pkTipoDocum` int(11) NOT NULL,
  `nombreTipoDocum` varchar(10) DEFAULT NULL,
  `descripcion` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
