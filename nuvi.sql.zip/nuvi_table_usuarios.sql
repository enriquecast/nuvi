
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE `usuarios` (
  `idUsuario` int(11) NOT NULL,
  `nombreUsuario` varchar(45) DEFAULT NULL,
  `apellidoUsuario` varchar(45) DEFAULT NULL,
  `fkTipoDocum` int(11) DEFAULT NULL,
  `nDocumentoUsuario` varchar(45) DEFAULT NULL,
  `passwordUsuario` varchar(45) DEFAULT NULL,
  `telefonoUsuario` varchar(45) DEFAULT NULL,
  `correoElectronico` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`idUsuario`, `nombreUsuario`, `apellidoUsuario`, `fkTipoDocum`, `nDocumentoUsuario`, `passwordUsuario`, `telefonoUsuario`, `correoElectronico`) VALUES
(1, 'Esteban', 'Rengifo', NULL, '5225522552', '12345', '5362618', 'esteban@gmail.com'),
(2, 'Gabriela', 'Leguizamon', NULL, '8585858585', '12345', '5896586', 'Gabi@gmail.com');
