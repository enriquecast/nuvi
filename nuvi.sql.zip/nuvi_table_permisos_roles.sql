
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `permisos_roles`
--

DROP TABLE IF EXISTS `permisos_roles`;
CREATE TABLE `permisos_roles` (
  `pkpermisosRoles` int(11) NOT NULL,
  `fkRol` int(11) NOT NULL,
  `fkPermisos` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
