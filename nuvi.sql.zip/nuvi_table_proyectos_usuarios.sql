
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `proyectos_usuarios`
--

DROP TABLE IF EXISTS `proyectos_usuarios`;
CREATE TABLE `proyectos_usuarios` (
  `idProyectoUsuarios` int(11) NOT NULL,
  `fkProyecto` int(11) DEFAULT NULL,
  `fkUsuario` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
