
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiales`
--

DROP TABLE IF EXISTS `materiales`;
CREATE TABLE `materiales` (
  `idMaterial` int(11) NOT NULL,
  `nombreMaterial` varchar(45) DEFAULT NULL,
  `unidadMedida` varchar(10) DEFAULT NULL,
  `descripción` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
