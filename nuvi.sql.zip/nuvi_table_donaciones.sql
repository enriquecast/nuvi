
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `donaciones`
--

DROP TABLE IF EXISTS `donaciones`;
CREATE TABLE `donaciones` (
  `idDonacion` int(11) NOT NULL,
  `nombreDonador` varchar(45) DEFAULT NULL,
  `apellidoDonador` varchar(45) DEFAULT NULL,
  `fkTipoDocum` int(11) DEFAULT NULL,
  `nDocumentoDonador` varchar(45) DEFAULT NULL,
  `nContactoDonador` varchar(45) DEFAULT NULL,
  `emailDonador` varchar(45) DEFAULT NULL,
  `valorDonacion` int(11) DEFAULT NULL,
  `fechaDonacion` date DEFAULT NULL,
  `direccion` varchar(30) DEFAULT NULL,
  `ciudad` varchar(30) DEFAULT NULL,
  `fkProyecto` int(11) DEFAULT NULL,
  `imgComporbante` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
