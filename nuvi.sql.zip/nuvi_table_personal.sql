
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `personal`
--

DROP TABLE IF EXISTS `personal`;
CREATE TABLE `personal` (
  `idPersonal` int(11) NOT NULL,
  `nombrePersonal` varchar(45) DEFAULT NULL,
  `apellidoPersonal` varchar(45) DEFAULT NULL,
  `profesionPersonal` varchar(45) DEFAULT NULL,
  `fechaNacimiento` date DEFAULT NULL,
  `categoriaPersonal` varchar(45) DEFAULT NULL,
  `fkTipoDocum` int(11) DEFAULT NULL,
  `nDocumentoPersonal` varchar(45) DEFAULT NULL,
  `nContactoPersonal` varchar(45) DEFAULT NULL,
  `emailPersonal` varchar(45) DEFAULT NULL,
  `sueldo` int(11) DEFAULT NULL,
  `disponibilidad` enum('Disponible','Asignado a proyecto') DEFAULT NULL,
  `fkProyecto` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
