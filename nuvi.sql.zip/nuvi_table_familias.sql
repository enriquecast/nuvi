
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `familias`
--

DROP TABLE IF EXISTS `familias`;
CREATE TABLE `familias` (
  `idFamilia` int(11) NOT NULL,
  `fechaVisita` date DEFAULT NULL,
  `nombreCdeFamilia` varchar(45) DEFAULT NULL,
  `apellidoCdeFamilia` varchar(45) DEFAULT NULL,
  `fkTipoDocum` int(11) DEFAULT NULL,
  `nDocumentoCdeFamilia` varchar(45) DEFAULT NULL,
  `nIntegrantesFamilia` int(11) DEFAULT NULL,
  `localidadFamilia` int(11) DEFAULT NULL,
  `barrioFamilia` varchar(45) DEFAULT NULL,
  `direccionFamilia` varchar(45) DEFAULT NULL,
  `ciudadFamilia` varchar(45) DEFAULT NULL,
  `fkTipoProblematica` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
