
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `materiales_proyecto`
--

DROP TABLE IF EXISTS `materiales_proyecto`;
CREATE TABLE `materiales_proyecto` (
  `idMaterialCotizacion` int(11) NOT NULL,
  `fkProyecto` int(11) DEFAULT NULL,
  `fkMaterial` int(11) DEFAULT NULL,
  `cantidadMaterial` float DEFAULT NULL,
  `valorunitario` float DEFAULT NULL,
  `importe` float DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
