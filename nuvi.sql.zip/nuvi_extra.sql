
--
-- Índices para tablas volcadas
--

--
-- Indices de la tabla `casos`
--
ALTER TABLE `casos`
  ADD PRIMARY KEY (`idCaso`),
  ADD KEY `fkUsuario` (`fkUsuario`);

--
-- Indices de la tabla `donaciones`
--
ALTER TABLE `donaciones`
  ADD PRIMARY KEY (`idDonacion`),
  ADD KEY `fkTipoDocum` (`fkTipoDocum`),
  ADD KEY `fkProyecto` (`fkProyecto`);

--
-- Indices de la tabla `familias`
--
ALTER TABLE `familias`
  ADD PRIMARY KEY (`idFamilia`),
  ADD KEY `fkTipoDocum` (`fkTipoDocum`),
  ADD KEY `fkTipoProblematica` (`fkTipoProblematica`);

--
-- Indices de la tabla `materiales`
--
ALTER TABLE `materiales`
  ADD PRIMARY KEY (`idMaterial`);

--
-- Indices de la tabla `materiales_proyecto`
--
ALTER TABLE `materiales_proyecto`
  ADD PRIMARY KEY (`idMaterialCotizacion`),
  ADD KEY `fkMaterial` (`fkMaterial`),
  ADD KEY `fkProyecto` (`fkProyecto`);

--
-- Indices de la tabla `permisos`
--
ALTER TABLE `permisos`
  ADD PRIMARY KEY (`idPermisos`);

--
-- Indices de la tabla `permisos_roles`
--
ALTER TABLE `permisos_roles`
  ADD PRIMARY KEY (`pkpermisosRoles`),
  ADD KEY `fkRol` (`fkRol`),
  ADD KEY `fkPermisos` (`fkPermisos`);

--
-- Indices de la tabla `personal`
--
ALTER TABLE `personal`
  ADD PRIMARY KEY (`idPersonal`),
  ADD KEY `fkTipoDocum` (`fkTipoDocum`),
  ADD KEY `fkProyecto` (`fkProyecto`);

--
-- Indices de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD PRIMARY KEY (`idProyecto`),
  ADD KEY `fkFamilia` (`fkFamilia`);

--
-- Indices de la tabla `proyectos_usuarios`
--
ALTER TABLE `proyectos_usuarios`
  ADD PRIMARY KEY (`idProyectoUsuarios`),
  ADD KEY `fkProyecto` (`fkProyecto`),
  ADD KEY `fkUsuario` (`fkUsuario`);

--
-- Indices de la tabla `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`idRol`);

--
-- Indices de la tabla `tipodocumentos`
--
ALTER TABLE `tipodocumentos`
  ADD PRIMARY KEY (`pkTipoDocum`);

--
-- Indices de la tabla `tipoproblematicas`
--
ALTER TABLE `tipoproblematicas`
  ADD PRIMARY KEY (`idTipoProblematica`);

--
-- Indices de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD PRIMARY KEY (`idUsuario`),
  ADD KEY `fkTipoDocum` (`fkTipoDocum`);

--
-- Indices de la tabla `usuarios_roles`
--
ALTER TABLE `usuarios_roles`
  ADD PRIMARY KEY (`idUsuariosRoles`),
  ADD KEY `fkUsuario` (`fkUsuario`),
  ADD KEY `fkRol` (`fkRol`);

--
-- AUTO_INCREMENT de las tablas volcadas
--

--
-- AUTO_INCREMENT de la tabla `casos`
--
ALTER TABLE `casos`
  MODIFY `idCaso` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT de la tabla `donaciones`
--
ALTER TABLE `donaciones`
  MODIFY `idDonacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `familias`
--
ALTER TABLE `familias`
  MODIFY `idFamilia` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `materiales`
--
ALTER TABLE `materiales`
  MODIFY `idMaterial` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `materiales_proyecto`
--
ALTER TABLE `materiales_proyecto`
  MODIFY `idMaterialCotizacion` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `permisos`
--
ALTER TABLE `permisos`
  MODIFY `idPermisos` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `permisos_roles`
--
ALTER TABLE `permisos_roles`
  MODIFY `pkpermisosRoles` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `personal`
--
ALTER TABLE `personal`
  MODIFY `idPersonal` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proyectos`
--
ALTER TABLE `proyectos`
  MODIFY `idProyecto` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `proyectos_usuarios`
--
ALTER TABLE `proyectos_usuarios`
  MODIFY `idProyectoUsuarios` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `roles`
--
ALTER TABLE `roles`
  MODIFY `idRol` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipodocumentos`
--
ALTER TABLE `tipodocumentos`
  MODIFY `pkTipoDocum` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `tipoproblematicas`
--
ALTER TABLE `tipoproblematicas`
  MODIFY `idTipoProblematica` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT de la tabla `usuarios`
--
ALTER TABLE `usuarios`
  MODIFY `idUsuario` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT de la tabla `usuarios_roles`
--
ALTER TABLE `usuarios_roles`
  MODIFY `idUsuariosRoles` int(11) NOT NULL AUTO_INCREMENT;

--
-- Restricciones para tablas volcadas
--

--
-- Filtros para la tabla `casos`
--
ALTER TABLE `casos`
  ADD CONSTRAINT `casos_ibfk_1` FOREIGN KEY (`fkUsuario`) REFERENCES `usuarios` (`idUsuario`);

--
-- Filtros para la tabla `donaciones`
--
ALTER TABLE `donaciones`
  ADD CONSTRAINT `donaciones_ibfk_1` FOREIGN KEY (`fkTipoDocum`) REFERENCES `tipodocumentos` (`pkTipoDocum`),
  ADD CONSTRAINT `donaciones_ibfk_2` FOREIGN KEY (`fkProyecto`) REFERENCES `proyectos` (`idProyecto`);

--
-- Filtros para la tabla `familias`
--
ALTER TABLE `familias`
  ADD CONSTRAINT `familias_ibfk_1` FOREIGN KEY (`fkTipoDocum`) REFERENCES `tipodocumentos` (`pkTipoDocum`),
  ADD CONSTRAINT `familias_ibfk_2` FOREIGN KEY (`fkTipoProblematica`) REFERENCES `tipoproblematicas` (`idTipoProblematica`);

--
-- Filtros para la tabla `materiales_proyecto`
--
ALTER TABLE `materiales_proyecto`
  ADD CONSTRAINT `materiales_proyecto_ibfk_1` FOREIGN KEY (`fkMaterial`) REFERENCES `materiales` (`idMaterial`),
  ADD CONSTRAINT `materiales_proyecto_ibfk_2` FOREIGN KEY (`fkProyecto`) REFERENCES `proyectos` (`idProyecto`);

--
-- Filtros para la tabla `permisos_roles`
--
ALTER TABLE `permisos_roles`
  ADD CONSTRAINT `permisos_roles_ibfk_1` FOREIGN KEY (`fkRol`) REFERENCES `roles` (`idRol`),
  ADD CONSTRAINT `permisos_roles_ibfk_2` FOREIGN KEY (`fkPermisos`) REFERENCES `permisos` (`idPermisos`);

--
-- Filtros para la tabla `personal`
--
ALTER TABLE `personal`
  ADD CONSTRAINT `personal_ibfk_1` FOREIGN KEY (`fkTipoDocum`) REFERENCES `tipodocumentos` (`pkTipoDocum`),
  ADD CONSTRAINT `personal_ibfk_2` FOREIGN KEY (`fkProyecto`) REFERENCES `proyectos` (`idProyecto`);

--
-- Filtros para la tabla `proyectos`
--
ALTER TABLE `proyectos`
  ADD CONSTRAINT `proyectos_ibfk_1` FOREIGN KEY (`fkFamilia`) REFERENCES `familias` (`idFamilia`);

--
-- Filtros para la tabla `proyectos_usuarios`
--
ALTER TABLE `proyectos_usuarios`
  ADD CONSTRAINT `proyectos_usuarios_ibfk_1` FOREIGN KEY (`fkProyecto`) REFERENCES `proyectos` (`idProyecto`),
  ADD CONSTRAINT `proyectos_usuarios_ibfk_2` FOREIGN KEY (`fkUsuario`) REFERENCES `usuarios` (`idUsuario`);

--
-- Filtros para la tabla `usuarios`
--
ALTER TABLE `usuarios`
  ADD CONSTRAINT `usuarios_ibfk_1` FOREIGN KEY (`fkTipoDocum`) REFERENCES `tipodocumentos` (`pkTipoDocum`);

--
-- Filtros para la tabla `usuarios_roles`
--
ALTER TABLE `usuarios_roles`
  ADD CONSTRAINT `usuarios_roles_ibfk_1` FOREIGN KEY (`fkUsuario`) REFERENCES `usuarios` (`idUsuario`),
  ADD CONSTRAINT `usuarios_roles_ibfk_2` FOREIGN KEY (`fkRol`) REFERENCES `roles` (`idRol`);
