
-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `casos`
--

DROP TABLE IF EXISTS `casos`;
CREATE TABLE `casos` (
  `idCaso` int(11) NOT NULL,
  `nombreUsuario` varchar(45) DEFAULT NULL,
  `EmailUsuario` varchar(45) DEFAULT NULL,
  `DetalleProblema` varchar(300) DEFAULT NULL,
  `DetalleSolución` varchar(300) DEFAULT NULL,
  `EstadoCaso` enum('Por asignación','Asignado','Resuelto','Cerrado') DEFAULT NULL,
  `fkUsuario` int(11) DEFAULT NULL,
  `calificacion` enum('1','2','3','4','5') DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Volcado de datos para la tabla `casos`
--

INSERT INTO `casos` (`idCaso`, `nombreUsuario`, `EmailUsuario`, `DetalleProblema`, `DetalleSolución`, `EstadoCaso`, `fkUsuario`, `calificacion`) VALUES
(1, 'Diego', NULL, 'jejejejejej', 'jjjjj', 'Resuelto', 1, NULL),
(2, 'Diego', 'diego@gmail.com', 'No deja entrar', NULL, 'Resuelto', 1, NULL),
(3, 'Diego', 'Diego', 'jjjjj', NULL, 'Por asignación', NULL, NULL);
